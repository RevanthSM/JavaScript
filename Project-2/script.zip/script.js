"use strict";
const model = document.querySelector(".model");
const overlay = document.querySelector(".overlay");
const btnCloseModel = document.querySelector(".close-model");
const btnsOpenModel = document.querySelector(".show-model");
console.log(btnsOpenModel);

for (let i = 0; i < btnsOpenModel.length; i++) {
  console.log(btnsOpenModel[i].textContent);
}
